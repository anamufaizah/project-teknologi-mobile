import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: MenuMakanan(),
  ));
}

class MenuMakanan extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menu Makanan'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: [
          buildMenuItem(context, 'Makanan 1', 10000, 'images/makanan1.jpg'),
          buildMenuItem(context, 'Makanan 2', 15000, 'images/makanan2.jpg'),
          buildMenuItem(context, 'Makanan 3', 12000, 'images/makanan3.jpg'),
          buildMenuItem(context, 'Makanan 4', 18000, 'images/makanan4.jpg'),
          buildMenuItem(context, 'Makanan 5', 9000, 'images/makanan5.jpg'),
          buildMenuItem(context, 'Makanan 6', 20000, 'images/makanan6.jpg'),
        ],
      ),
    );
  }

  Widget buildMenuItem(
      BuildContext context, String nama, int harga, String imagePath) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailMenuMakanan(
                nama: nama, harga: harga, imagePath: imagePath),
          ),
        );
      },
      child: Card(
        margin: EdgeInsets.all(20),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              imagePath,
              width: 300,
              height: 300,
            ),
            SizedBox(height: 10),
            Text(
              nama,
              style: TextStyle(fontSize: 24),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailMenuMakanan extends StatefulWidget {
  final String nama;
  final int harga;
  final String imagePath;

  const DetailMenuMakanan(
      {Key? key,
      required this.nama,
      required this.harga,
      required this.imagePath})
      : super(key: key);

  @override
  _DetailMenuMakananState createState() => _DetailMenuMakananState();
}

class _DetailMenuMakananState extends State<DetailMenuMakanan> {
  int jumlahPesanan = 1;
  late int totalHarga;

  @override
  void initState() {
    super.initState();
    totalHarga = widget.harga;
  }

  void hitungTotalHarga() {
    setState(() {
      totalHarga = widget.harga * jumlahPesanan;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Menu'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              widget.imagePath,
              width: 300,
              height: 300,
            ),
            SizedBox(height: 20),
            Text(
              widget.nama,
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Text(
              'Total Harga: Rp $totalHarga',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: () {
                    setState(() {
                      if (jumlahPesanan > 1) {
                        jumlahPesanan--;
                        hitungTotalHarga();
                      }
                    });
                  },
                  icon: Icon(Icons.remove),
                ),
                Text(
                  '$jumlahPesanan',
                  style: TextStyle(fontSize: 20),
                ),
                IconButton(
                  onPressed: () {
                    setState(() {
                      jumlahPesanan++;
                      hitungTotalHarga();
                    });
                  },
                  icon: Icon(Icons.add),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
